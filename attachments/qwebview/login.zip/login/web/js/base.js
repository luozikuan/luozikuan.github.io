$(function(){
	$("button").click(function(){
		$(".Mask").css({display:"block"});
	})
	$(".login_title_close").click(function(){
		$(".Mask").css({display:"none"});
	})
});


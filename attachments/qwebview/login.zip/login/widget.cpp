#include <QWebView>
#include <QWebFrame>
#include <QDebug>

#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->webView->setAcceptDrops(false);
    QString loginFile = "/Users/luozikuan/Developer/qt/build-login-unknown-Debug/web/index 2.html";
    ui->webView->setUrl(QUrl(QString("file:///%1").arg(loginFile)));
    connect(ui->webView->page()->mainFrame(), SIGNAL(javaScriptWindowObjectCleared()),
            this, SLOT(addToJavascript()));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::addToJavascript()
{
    ui->webView->page()->mainFrame()->addToJavaScriptWindowObject("xxx", this);
}

void Widget::onDocReady()
{
    QString username = getRememberedUsr();
    QString password = getRememberedPwd();
    QString js = QString("fillUsrAndPwd('%1','%2');").arg(username).arg(password);
    ui->webView->page()->mainFrame()->evaluateJavaScript(js);
}

QString Widget::getRememberedUsr()
{
    return "luozikuan";
}

QString Widget::getRememberedPwd()
{
    return "123456";
}

void Widget::submit(QString username, QString password, QString func)
{
    if ("luozikuan" == username && "123456" == password) {
        qDebug() << tr("login success");
    } else {
        qDebug() << tr("wrong username or password");
    }
    qDebug() << func;
}

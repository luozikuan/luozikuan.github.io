#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

public slots:
    void addToJavascript();
    void onDocReady();
    void submit(QString username, QString password, QString func);

private:
    QString getRememberedUsr();
    QString getRememberedPwd();
    Ui::Widget *ui;
};

#endif // WIDGET_H
